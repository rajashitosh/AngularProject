import { CommonModule } from '@angular/common';
import { HttpClient } from '@angular/common/http';
import { Component, NgModule } from '@angular/core';
import { error } from 'node:console'
import { FormsModule } from '@angular/forms'; 

@Component({
  selector: 'app-user-list',
  imports: [CommonModule, FormsModule],
  templateUrl: './user-list.component.html',
  styleUrl: './user-list.component.css'
})
export class UserListComponent {

  userList: any[] = [];

  constructor(private http: HttpClient){

    this.getAllUser();
  }

  getAllUser(){
    
    this.http.get("http://localhost:8090/api/users").subscribe((res:any)=>{

      this.userList = res;

      console.log(this.userList);

    },error=>{
      console.log(error);
    })
  }


  userObj:any = {
    "name" : "",
    "email" : "",
    "about" : ""
  }

  onSave(event:Event) {
    event.preventDefault(); // Prevent the form from refreshing the page
    this.http.post("http://localhost:8090/api/users", this.userObj).subscribe((res: any) => {
      console.log(res);
      if(res.userId != null){
        alert("user created with id"+ res.userId);
        window.location.reload();
      }
    });
  }
  

}
