import { CommonModule } from '@angular/common';
import { HttpClient } from '@angular/common/http';
import { Component } from '@angular/core';
import { error } from 'console';

@Component({
  selector: 'app-hotel-list',
  imports: [CommonModule],
  templateUrl: './hotel-list.component.html',
  styleUrl: './hotel-list.component.css'
})
export class HotelListComponent {

  hotelList : any[] = [];

  constructor(private http: HttpClient){

    this.getAllHotelList();
  }

  getAllHotelList(){
    this.http.get("http://localhost:8092/api/hotels").subscribe((res:any)=>{
      this.hotelList = res;
    },
    error=>{
      console.log(error)
    }
  )
  }

}
